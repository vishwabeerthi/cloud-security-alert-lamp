# Cloud Security Alert Lamp - Web Version

This is a browser-based Flask version of the original Tkinter demonstration.

## Run locally
1. Install Python 3.9+
2. In this folder run: `python -m pip install -r requirements.txt`
3. Run: `python application.py`
4. Open `http://127.0.0.1:5000`

Demo credentials: `admin` / `1234`
Normal test IP: `192.168.1.10`
Demo blocked IPs: `192.168.1.99`, `10.0.0.99`

## AWS Elastic Beanstalk
This folder is structured for the AWS Elastic Beanstalk Python platform.
Create an Elastic Beanstalk Python environment and upload this ZIP as the application source bundle.
Set an environment variable named `SECRET_KEY` to a long random value before using beyond a classroom demo.

## Important limitations
This remains an educational simulation. The IP address is manually entered; it does not identify the visitor's real public IP. The blocklist is hard-coded demo data. Credentials are hard-coded for demonstration only. Session-based counters/logs are not a durable database and may reset when the browser session changes. Do not use for real account security.
