import os
import ipaddress
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
application = app
application.secret_key = os.environ.get("SECRET_KEY", "change-this-demo-secret-before-production")

MAX_ATTEMPTS = 3
DEMO_BLOCKED_IPS = {"192.168.1.99", "10.0.0.99"}

def initialize():
    session.setdefault("failed_attempts", 0)
    session.setdefault("successful_attempts", 0)
    session.setdefault("consecutive_failures", 0)
    session.setdefault("account_locked", False)
    session.setdefault("events", [])
    session.setdefault("lamp_color", "green")
    session.setdefault("status", "SYSTEM READY")

def add_event(message):
    events = session.get("events", [])
    events.insert(0, f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {message}")
    session["events"] = events[:100]

@application.route("/", methods=["GET", "POST"])
def index():
    initialize()

    if request.method == "POST":
        action = request.form.get("action")

        if action == "reset":
            for key in ("failed_attempts", "successful_attempts", "consecutive_failures"):
                session[key] = 0
            session["account_locked"] = False
            session["events"] = []
            session["lamp_color"] = "green"
            session["status"] = "SYSTEM READY"
            add_event("Demo system reset - account unlocked")
            flash(("success", "Demo system reset. Account unlocked."))
            return redirect(url_for("index"))

        if action == "login":
            if session["account_locked"]:
                flash(("error", "Account is locked. Press Reset System to unlock the demo."))
                return redirect(url_for("index"))

            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            ip_text = request.form.get("ip_address", "").strip()

            if not username or not password or not ip_text:
                flash(("error", "Please fill in username, password and IP address."))
                return redirect(url_for("index"))

            try:
                ipaddress.ip_address(ip_text)
            except ValueError:
                session["lamp_color"] = "amber"
                session["status"] = "INVALID IP ADDRESS"
                add_event(f"INVALID IP ADDRESS ENTERED | {ip_text}")
                flash(("error", "Invalid IP. Enter a valid IPv4 or IPv6 address."))
                return redirect(url_for("index"))

            if ip_text in DEMO_BLOCKED_IPS:
                session["lamp_color"] = "red"
                session["status"] = "SUSPICIOUS IP DETECTED - ACCESS DENIED"
                add_event(f"BLOCKED DEMO IP - ACCESS DENIED | {ip_text}")
                flash(("error", f"Access denied for {ip_text}. This is in the demo blocklist."))
                return redirect(url_for("index"))

            if username == "admin" and password == "1234":
                session["successful_attempts"] += 1
                session["consecutive_failures"] = 0
                session["lamp_color"] = "green"
                session["status"] = "SECURE ACCESS GRANTED"
                add_event(f"SUCCESSFUL LOGIN | User: {username} | IP: {ip_text}")
                flash(("success", "Authentication successful!"))
            else:
                session["failed_attempts"] += 1
                session["consecutive_failures"] += 1
                add_event(f"FAILED LOGIN | User: {username} | IP: {ip_text}")
                if session["consecutive_failures"] >= MAX_ATTEMPTS:
                    session["account_locked"] = True
                    session["lamp_color"] = "red"
                    session["status"] = "ACCOUNT LOCKED - TOO MANY FAILED ATTEMPTS"
                    add_event("ACCOUNT LOCKED after 3 consecutive failed attempts")
                    flash(("error", "Three consecutive incorrect attempts detected. Demo account locked."))
                else:
                    session["lamp_color"] = "amber"
                    session["status"] = "WARNING - FAILED LOGIN DETECTED"
                    remaining = MAX_ATTEMPTS - session["consecutive_failures"]
                    flash(("warning", f"Incorrect credentials. {remaining} attempt(s) remaining before lockout."))

            return redirect(url_for("index"))

    if not session.get("events"):
        add_event("Security monitoring simulation started")
        add_event("Demo IP blocklist loaded")
        add_event("System ready")

    return render_template("index.html", max_attempts=MAX_ATTEMPTS,
                           blocked_ips=sorted(DEMO_BLOCKED_IPS))

if __name__ == "__main__":
    application.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
